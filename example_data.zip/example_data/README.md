# ExChanGeAI Demo Data

Please load with 100hz sampling rate!

This data has been derived from the [PTB-XL](https://physionet.org/content/ptb-xl/1.0.3/) dataset, which is published under the [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode.en). These files are a subset, which only cover bundle branch blocks from fold 9. This subset is identical to the used dataset during the training of models of the ExChanGeAI paper. For further details, please refer to the paper. In compliance with the original attribution, this subset is provided under the same `CC BY 4.0 license`.

If you use this data, please give credit to the dataset:

```
Wagner, P., Strodthoff, N., Bousseljot, R., Samek, W., & Schaeffter, T. (2022). PTB-XL, a large publicly available electrocardiography dataset (version 1.0.3). PhysioNet. https://doi.org/10.13026/kfzx-aw45.
```